package com.htmlapp.builder;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.*;
import android.content.pm.PackageInstaller;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.widget.*;
import java.io.*;

public class MainActivity extends Activity {
    static final int PICK_HTML = 1, PICK_LOGO = 2;
    static final String ACTION = "com.htmlapp.builder.INSTALL_RESULT";
    Uri htmlUri, logoUri;
    String htmlName = "";
    EditText nameEt;
    TextView htmlTv, statusTv;
    ImageView logoIv;
    Button buildBtn;
    ProgressBar bar;
    BroadcastReceiver rx;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    Button btn(String t, int color) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(14));
        b.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.topMargin = dp(12);
        b.setLayoutParams(lp);
        return b;
    }

    TextView tv(String t, int sp, int color) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setPadding(0, dp(8), 0, 0);
        return v;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#101318"));
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(48), dp(20), dp(32));
        sv.addView(l);
        setContentView(sv);

        TextView title = tv("HTML App Builder", 26, Color.WHITE);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        l.addView(title);
        l.addView(tv("Turn an HTML file or ZIP into an installable app.", 14, Color.parseColor("#9AA4B2")));

        nameEt = new EditText(this);
        nameEt.setHint("App name");
        nameEt.setTextColor(Color.WHITE);
        nameEt.setHintTextColor(Color.GRAY);
        nameEt.setSingleLine(true);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-1, -2);
        nlp.topMargin = dp(20);
        l.addView(nameEt, nlp);

        Button htmlBtn = btn("Choose HTML file or ZIP", Color.parseColor("#2B3340"));
        l.addView(htmlBtn);
        htmlTv = tv("No file chosen", 13, Color.parseColor("#9AA4B2"));
        l.addView(htmlTv);

        Button logoBtn = btn("Choose logo", Color.parseColor("#2B3340"));
        l.addView(logoBtn);
        logoIv = new ImageView(this);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(72), dp(72));
        ilp.topMargin = dp(10);
        ilp.gravity = Gravity.START;
        l.addView(logoIv, ilp);

        buildBtn = btn("Build and install", Color.parseColor("#4F46E5"));
        LinearLayout.LayoutParams blp = (LinearLayout.LayoutParams) buildBtn.getLayoutParams();
        blp.topMargin = dp(24);
        l.addView(buildBtn);
        bar = new ProgressBar(this);
        bar.setVisibility(android.view.View.GONE);
        l.addView(bar);
        statusTv = tv("", 14, Color.WHITE);
        l.addView(statusTv);

        htmlBtn.setOnClickListener(v -> pick("*/*", PICK_HTML, new String[]{"text/html", "application/zip", "application/x-zip-compressed", "application/octet-stream"}));
        logoBtn.setOnClickListener(v -> pick("image/*", PICK_LOGO, null));
        buildBtn.setOnClickListener(v -> startBuild());

        rx = new BroadcastReceiver() {
            @SuppressWarnings("deprecation")
            @Override public void onReceive(Context c, Intent i) {
                int st = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
                if (st == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                    Intent confirm = i.getParcelableExtra(Intent.EXTRA_INTENT);
                    if (confirm != null) startActivity(confirm);
                } else if (st == PackageInstaller.STATUS_SUCCESS) status("Installed. A copy is in Downloads/HTMLApps.");
                else status("Install stopped: " + i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE));
            }
        };
        IntentFilter f = new IntentFilter(ACTION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(rx, f);
    }

    void pick(String type, int code, String[] mimes) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(type);
        if (mimes != null) i.putExtra(Intent.EXTRA_MIME_TYPES, mimes);
        startActivityForResult(i, code);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        if (req == PICK_HTML) {
            htmlUri = u;
            htmlName = queryName(u);
            htmlTv.setText(htmlName);
        } else if (req == PICK_LOGO) {
            logoUri = u;
            logoIv.setImageURI(u);
        }
    }

    String queryName(Uri u) {
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME));
        } catch (Exception ignored) { }
        return "file";
    }

    void status(final String s) { runOnUiThread(() -> statusTv.setText(s)); }

    void busy(final boolean on) {
        runOnUiThread(() -> { bar.setVisibility(on ? android.view.View.VISIBLE : android.view.View.GONE); buildBtn.setEnabled(!on); });
    }

    byte[] read(Uri u) throws IOException {
        try (InputStream in = getContentResolver().openInputStream(u)) { return ApkBuilder.readAll(in); }
    }

    void startBuild() {
        final String name = nameEt.getText().toString().trim();
        if (name.isEmpty()) { status("Enter an app name."); return; }
        if (htmlUri == null) { status("Choose an HTML file or ZIP."); return; }
        if (logoUri == null) { status("Choose a logo."); return; }
        busy(true);
        status("Building…");
        new Thread(() -> {
            try {
                File apk = ApkBuilder.build(this, name, htmlName, read(htmlUri), read(logoUri));
                saveCopy(apk, name);
                status("Built. Confirm the install prompt.");
                busy(false);
                runOnUiThread(() -> install(apk));
            } catch (Throwable t) {
                status("Failed: " + t);
                busy(false);
            }
        }).start();
    }

    void saveCopy(File apk, String name) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, apk.getName());
            v.put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.android.package-archive");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/HTMLApps");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            try (OutputStream o = getContentResolver().openOutputStream(u); InputStream in = new FileInputStream(apk)) { ApkBuilder.copy(in, o); }
        } catch (Exception ignored) { }
    }

    void install(File apk) {
        try {
            PackageInstaller pi = getPackageManager().getPackageInstaller();
            int id = pi.createSession(new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL));
            try (PackageInstaller.Session s = pi.openSession(id)) {
                try (OutputStream o = s.openWrite("app.apk", 0, apk.length()); InputStream in = new FileInputStream(apk)) {
                    ApkBuilder.copy(in, o);
                    s.fsync(o);
                }
                PendingIntent p = PendingIntent.getBroadcast(this, id, new Intent(ACTION).setPackage(getPackageName()),
                        PendingIntent.FLAG_MUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                s.commit(p.getIntentSender());
            }
        } catch (Exception e) { status("Install failed: " + e); }
    }

    @Override protected void onDestroy() { super.onDestroy(); unregisterReceiver(rx); }
}
