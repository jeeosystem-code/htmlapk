package com.htmlapp.builder;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/** Replaces strings inside a compiled (binary) AndroidManifest.xml. */
final class AxmlPatcher {
    static byte[] patch(byte[] d, Map<String, String> repl) {
        ByteBuffer b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
        int pos = 8;
        if ((b.getShort(0) & 0xFFFF) != 0x0003 || (b.getShort(pos) & 0xFFFF) != 0x0001)
            throw new IllegalStateException("Unexpected manifest format");
        int hdr = b.getShort(pos + 2) & 0xFFFF;
        int poolSize = b.getInt(pos + 4);
        int count = b.getInt(pos + 8);
        int styles = b.getInt(pos + 12);
        boolean utf8 = (b.getInt(pos + 16) & 0x100) != 0;
        int strStart = b.getInt(pos + 20);
        if (styles != 0) throw new IllegalStateException("Styled strings not supported");
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        int[] offs = new int[count];
        for (int i = 0; i < count; i++) {
            int p = pos + strStart + b.getInt(pos + hdr + i * 4);
            String s = utf8 ? readUtf8(d, p) : readUtf16(d, p);
            if (repl.containsKey(s)) s = repl.get(s);
            offs[i] = data.size();
            writeUtf16(data, s);
        }
        while (data.size() % 4 != 0) data.write(0);
        int newStart = 28 + count * 4;
        int newPool = newStart + data.size();
        int restFrom = pos + poolSize;
        int total = 8 + newPool + (d.length - restFrom);
        ByteBuffer o = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN);
        o.putShort((short) 0x0003).putShort((short) 8).putInt(total);
        o.putShort((short) 0x0001).putShort((short) 28).putInt(newPool).putInt(count).putInt(0).putInt(0).putInt(newStart).putInt(0);
        for (int off : offs) o.putInt(off);
        o.put(data.toByteArray());
        o.put(d, restFrom, d.length - restFrom);
        return o.array();
    }

    private static String readUtf16(byte[] d, int p) {
        int len = (d[p] & 0xFF) | ((d[p + 1] & 0xFF) << 8);
        int off = 2;
        if ((len & 0x8000) != 0) {
            len = ((len & 0x7FFF) << 16) | (d[p + 2] & 0xFF) | ((d[p + 3] & 0xFF) << 8);
            off = 4;
        }
        return new String(d, p + off, len * 2, StandardCharsets.UTF_16LE);
    }

    private static String readUtf8(byte[] d, int p) {
        p += (d[p] & 0x80) != 0 ? 2 : 1;
        int bl = d[p] & 0xFF, step = 1;
        if ((bl & 0x80) != 0) { bl = ((bl & 0x7F) << 8) | (d[p + 1] & 0xFF); step = 2; }
        return new String(d, p + step, bl, StandardCharsets.UTF_8);
    }

    private static void writeUtf16(ByteArrayOutputStream o, String s) {
        int n = s.length();
        if (n > 0x7FFF) {
            int hi = (n >> 16) | 0x8000;
            o.write(hi & 0xFF); o.write(hi >> 8);
            o.write(n & 0xFF); o.write((n >> 8) & 0xFF);
        } else { o.write(n & 0xFF); o.write(n >> 8); }
        byte[] c = s.getBytes(StandardCharsets.UTF_16LE);
        o.write(c, 0, c.length);
        o.write(0); o.write(0);
    }
}
