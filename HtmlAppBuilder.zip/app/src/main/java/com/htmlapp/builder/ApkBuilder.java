package com.htmlapp.builder;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import com.android.apksig.ApkSigner;
import java.io.*;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.KeyFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import java.util.zip.*;

final class ApkBuilder {
    static final String TEMPLATE_PKG = "com.htmlapp.template";
    static final String TEMPLATE_LABEL = "HTMLAPPNAME";

    static File build(Context c, String appName, String fileName, byte[] content, byte[] logo) throws Exception {
        Map<String, byte[]> www = collectWww(content);
        byte[] icon = makeIcon(logo);
        String pkg = "com.htmlapp.a" + sha1hex(appName.toLowerCase(Locale.ROOT)).substring(0, 12);

        File tpl = new File(c.getCacheDir(), "template.apk");
        try (InputStream in = c.getAssets().open("template.apk"); OutputStream o = new FileOutputStream(tpl)) { copy(in, o); }

        Map<String, byte[]> out = new LinkedHashMap<>();
        try (ZipFile zf = new ZipFile(tpl)) {
            for (Enumeration<? extends ZipEntry> en = zf.entries(); en.hasMoreElements(); ) {
                ZipEntry e = en.nextElement();
                String n = e.getName();
                if (e.isDirectory() || n.startsWith("META-INF/") || n.startsWith("assets/www/")) continue;
                byte[] d;
                try (InputStream in = zf.getInputStream(e)) { d = readAll(in); }
                if (n.equals("AndroidManifest.xml")) {
                    Map<String, String> m = new HashMap<>();
                    m.put(TEMPLATE_PKG, pkg);
                    m.put(TEMPLATE_LABEL, appName);
                    d = AxmlPatcher.patch(d, m);
                } else if (n.startsWith("res/") && n.endsWith(".png")) {
                    d = icon;
                }
                out.put(n, d);
            }
        }
        for (Map.Entry<String, byte[]> e : www.entrySet()) out.put("assets/www/" + e.getKey(), e.getValue());

        File unsigned = new File(c.getCacheDir(), "unsigned.apk");
        File signed = new File(c.getCacheDir(), appName.replaceAll("[^A-Za-z0-9_-]", "_") + ".apk");
        writeAligned(unsigned, out);
        sign(c, unsigned, signed);
        return signed;
    }

    static Map<String, byte[]> collectWww(byte[] content) throws IOException {
        Map<String, byte[]> m = new LinkedHashMap<>();
        boolean zip = content.length > 3 && content[0] == 'P' && content[1] == 'K';
        if (!zip) { m.put("index.html", content); return m; }
        Map<String, byte[]> raw = new LinkedHashMap<>();
        try (ZipInputStream z = new ZipInputStream(new ByteArrayInputStream(content))) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                String n = e.getName().replace('\\', '/');
                if (e.isDirectory() || n.startsWith("__MACOSX/") || n.contains("..")) continue;
                raw.put(n, readAll(z));
            }
        }
        String prefix = null;
        if (raw.containsKey("index.html")) prefix = "";
        else {
            int best = Integer.MAX_VALUE;
            for (String n : raw.keySet()) {
                if (n.endsWith("/index.html")) {
                    int d = n.split("/").length;
                    if (d < best) { best = d; prefix = n.substring(0, n.length() - 10); }
                }
            }
        }
        if (prefix == null) throw new IOException("The ZIP must contain an index.html");
        for (Map.Entry<String, byte[]> e : raw.entrySet())
            if (e.getKey().startsWith(prefix)) m.put(e.getKey().substring(prefix.length()), e.getValue());
        return m;
    }

    static byte[] makeIcon(byte[] logo) throws IOException {
        Bitmap src = BitmapFactory.decodeByteArray(logo, 0, logo.length);
        if (src == null) throw new IOException("Could not read the logo image");
        int s = Math.min(src.getWidth(), src.getHeight());
        Bitmap sq = Bitmap.createBitmap(src, (src.getWidth() - s) / 2, (src.getHeight() - s) / 2, s, s);
        Bitmap icon = Bitmap.createScaledBitmap(sq, 192, 192, true);
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        icon.compress(Bitmap.CompressFormat.PNG, 100, o);
        return o.toByteArray();
    }

    /** Writes a zip where resources.arsc is stored uncompressed and 4-byte aligned (required for modern Android). */
    static void writeAligned(File f, Map<String, byte[]> entries) throws IOException {
        try (Counting co = new Counting(new BufferedOutputStream(new FileOutputStream(f)));
             ZipOutputStream zos = new ZipOutputStream(co)) {
            for (Map.Entry<String, byte[]> en : entries.entrySet()) {
                String name = en.getKey();
                byte[] data = en.getValue();
                ZipEntry e = new ZipEntry(name);
                if (name.equals("resources.arsc")) {
                    CRC32 crc = new CRC32();
                    crc.update(data);
                    e.setMethod(ZipEntry.STORED);
                    e.setSize(data.length);
                    e.setCompressedSize(data.length);
                    e.setCrc(crc.getValue());
                    long base = co.count + 30 + name.getBytes("UTF-8").length;
                    int pad = (int) ((4 - base % 4) % 4);
                    if (pad > 0) {
                        int L = pad + 4;
                        byte[] x = new byte[L];
                        x[0] = 0x35; x[1] = (byte) 0xD9; x[2] = (byte) (L - 4);
                        e.setExtra(x);
                    }
                } else {
                    e.setMethod(ZipEntry.DEFLATED);
                }
                zos.putNextEntry(e);
                zos.write(data);
                zos.closeEntry();
            }
        }
    }

    static void sign(Context c, File in, File out) throws Exception {
        byte[] k;
        try (InputStream is = c.getAssets().open("signing.pk8")) { k = readAll(is); }
        PrivateKey pk = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(k));
        X509Certificate cert;
        try (InputStream is = c.getAssets().open("signing.der")) {
            cert = (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(is);
        }
        ApkSigner.SignerConfig sc = new ApkSigner.SignerConfig.Builder("htmlapp", pk, Collections.singletonList(cert)).build();
        if (out.exists()) out.delete();
        new ApkSigner.Builder(Collections.singletonList(sc))
                .setInputApk(in).setOutputApk(out).setMinSdkVersion(29)
                .setV1SigningEnabled(true).setV2SigningEnabled(true).build().sign();
    }

    static String sha1hex(String s) throws Exception {
        byte[] h = MessageDigest.getInstance("SHA-1").digest(s.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : h) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        copy(in, o);
        return o.toByteArray();
    }

    static void copy(InputStream in, OutputStream o) throws IOException {
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
    }

    static final class Counting extends FilterOutputStream {
        long count;
        Counting(OutputStream o) { super(o); }
        @Override public void write(int b) throws IOException { out.write(b); count++; }
        @Override public void write(byte[] b, int off, int len) throws IOException { out.write(b, off, len); count += len; }
    }
}
