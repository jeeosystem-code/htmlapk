package com.htmlapp.template;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import java.util.Random;

/** Aurora background + orbiting comet rings + particles + staggered title, closing as an iris. */
class SplashView extends View {
    static final int BG = 0xFF0B0D12;
    private static final float[] BX = {0.25f, 0.8f, 0.45f}, BY = {0.22f, 0.55f, 0.85f},
            AX = {0.15f, 0.12f, 0.2f}, AY = {0.10f, 0.12f, 0.08f}, SP = {0.5f, 0.45f, 0.35f};

    private final float d;
    private final Bitmap icon;
    private final String[] chars;
    private final float[] widths;
    private final int c0, c1, c2;
    private final Paint blob = new Paint(Paint.ANTI_ALIAS_FLAG), glow = new Paint(Paint.ANTI_ALIAS_FLAG),
            ring = new Paint(Paint.ANTI_ALIAS_FLAG), dot = new Paint(Paint.ANTI_ALIAS_FLAG),
            logo = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG),
            text = new Paint(Paint.ANTI_ALIAS_FLAG), bar = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Shader[] blobSh = new Shader[3];
    private final BitmapShader iconSh;
    private final Matrix m = new Matrix();
    private final RectF rect = new RectF();
    private final float[][] parts = new float[36][5];
    private float W, H, cx, cy, blobR, glowR, spacing, textW;
    private float t, exitP;
    private long start;
    private ValueAnimator loop;

    SplashView(Context ctx, Bitmap icon, String name) {
        super(ctx);
        d = ctx.getResources().getDisplayMetrics().density;
        this.icon = icon;
        int[] cps = name.codePoints().toArray();
        chars = new String[cps.length];
        widths = new float[cps.length];
        for (int i = 0; i < cps.length; i++) chars[i] = new String(Character.toChars(cps[i]));

        float[] hsv = new float[3];
        Color.colorToHSV(Bitmap.createScaledBitmap(icon, 1, 1, true).getPixel(0, 0), hsv);
        float h = hsv[1] < 0.15f ? 250f : hsv[0];
        c0 = Color.HSVToColor(new float[]{h, 0.65f, 1f});
        c1 = Color.HSVToColor(new float[]{(h + 55f) % 360f, 0.6f, 1f});
        c2 = Color.HSVToColor(new float[]{(h + 305f) % 360f, 0.6f, 1f});

        Random r = new Random(7);
        for (float[] p : parts) {
            p[0] = r.nextFloat() * 6.2832f;
            p[1] = 80f + r.nextFloat() * 100f;
            p[2] = (r.nextBoolean() ? 1 : -1) * (0.12f + r.nextFloat() * 0.35f);
            p[3] = 1f + r.nextFloat() * 1.6f;
            p[4] = r.nextFloat() * 6.2832f;
        }
        iconSh = new BitmapShader(icon, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        logo.setShader(iconSh);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(2.5f * d);
        ring.setStrokeCap(Paint.Cap.ROUND);
        text.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        text.setColor(Color.WHITE);
        setClickable(true);
    }

    private static int a(int color, int alpha) { return (color & 0x00FFFFFF) | (alpha << 24); }
    private static float clamp(float x) { return x < 0f ? 0f : (x > 1f ? 1f : x); }
    private static float easeOut(float x) { float k = 1f - x; return 1f - k * k * k; }
    private static float easeBack(float x) { float k = x - 1f; return 1f + 2.70158f * k * k * k + 1.70158f * k * k; }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        W = w; H = h; cx = w / 2f; cy = h * 0.42f;
        blobR = Math.max(w, h) * 0.6f;
        int[] cc = {c0, c1, c2};
        for (int i = 0; i < 3; i++)
            blobSh[i] = new RadialGradient(0, 0, blobR, new int[]{a(cc[i], 120), a(cc[i], 0)}, null, Shader.TileMode.CLAMP);
        glowR = 110f * d;
        glow.setShader(new RadialGradient(0, 0, glowR, new int[]{a(c0, 150), a(c0, 0)}, null, Shader.TileMode.CLAMP));
        ring.setShader(new SweepGradient(0, 0, new int[]{a(c0, 0), c0, c1}, new float[]{0f, 0.55f, 0.75f}));
        float size = 22f * d;
        spacing = 3f * d;
        text.setTextSize(size);
        float total = 0;
        for (int i = 0; i < chars.length; i++) { widths[i] = text.measureText(chars[i]); total += widths[i] + spacing; }
        total -= spacing;
        float max = w * 0.82f;
        if (total > max) {
            float k = max / total;
            text.setTextSize(size * k);
            spacing *= k;
            total = 0;
            for (int i = 0; i < chars.length; i++) { widths[i] = text.measureText(chars[i]); total += widths[i] + spacing; }
            total -= spacing;
        }
        textW = total;
    }

    @Override protected void onDraw(Canvas c) {
        c.drawColor(BG);
        // aurora
        blob.setAlpha((int) (255 * clamp(t)));
        for (int i = 0; i < 3; i++) {
            float x = W * (BX[i] + AX[i] * (float) Math.sin(t * SP[i] + i));
            float y = H * (BY[i] + AY[i] * (float) Math.cos(t * SP[i] * 1.3f + i));
            blob.setShader(blobSh[i]);
            c.save(); c.translate(x, y); c.drawCircle(0, 0, blobR, blob); c.restore();
        }
        // particles
        float pf = easeOut(clamp((t - 0.3f) / 1.2f));
        dot.setColor(Color.WHITE);
        for (float[] p : parts) {
            float ang = p[0] + p[2] * t;
            float r = p[1] * d * (0.35f + 0.65f * pf) * (1f + 0.06f * (float) Math.sin(t * 0.9f + p[4]));
            float al = (0.25f + 0.75f * (0.5f + 0.5f * (float) Math.sin(t * 2.1f + p[4]))) * pf;
            dot.setAlpha((int) (200 * al));
            c.drawCircle(cx + (float) Math.cos(ang) * r, cy + (float) Math.sin(ang) * r * 0.92f, p[3] * d, dot);
        }
        // glow
        float gs = easeOut(clamp(t)) * (1f + 0.08f * (float) Math.sin(t * 2.2f));
        c.save(); c.translate(cx, cy); c.scale(gs, gs); c.drawCircle(0, 0, glowR, glow); c.restore();
        // comet rings
        float sw = 270f * easeOut(clamp((t - 0.25f) / 1.3f));
        if (sw > 1f) {
            c.save(); c.translate(cx, cy); c.rotate(t * 130f);
            ring.setAlpha(255); rect.set(-74 * d, -74 * d, 74 * d, 74 * d);
            c.drawArc(rect, 0, sw, false, ring); c.restore();
            c.save(); c.translate(cx, cy); c.rotate(90f - t * 85f);
            ring.setAlpha(150); rect.set(-62 * d, -62 * d, 62 * d, 62 * d);
            c.drawArc(rect, 0, sw * 0.8f, false, ring); c.restore();
        }
        // logo
        float sp = clamp((t - 0.15f) / 0.8f);
        float sc = easeBack(sp) * (1f + 0.3f * exitP);
        float size = 88f * d * sc;
        float bob = (float) Math.sin(t * 1.6f) * 3f * d * clamp((t - 0.95f) / 0.5f);
        if (size > 1f) {
            float l = cx - size / 2f, tp = cy + bob - size / 2f;
            m.setScale(size / icon.getWidth(), size / icon.getHeight());
            m.postTranslate(l, tp);
            iconSh.setLocalMatrix(m);
            logo.setAlpha((int) (255 * clamp(sp * 2f)));
            rect.set(l, tp, l + size, tp + size);
            c.drawRoundRect(rect, 22f * d * sc, 22f * d * sc, logo);
        }
        // title
        float x = cx - textW / 2f, base = cy + 122f * d, ex = clamp(1f - exitP * 2.5f);
        for (int i = 0; i < chars.length; i++) {
            float p = easeOut(clamp((t - 0.8f - i * 0.045f) / 0.55f));
            text.setAlpha((int) (255 * p * ex));
            c.drawText(chars[i], x, base + (1f - p) * 14f * d, text);
            x += widths[i] + spacing;
        }
        // loading line
        float bp = clamp((t - 1.5f) / 0.5f) * ex;
        if (bp > 0f) {
            float bw = 56f * d, bh = 2.5f * d, bx = cx - bw / 2f, by = cy + 152f * d;
            bar.setColor(Color.WHITE); bar.setAlpha((int) (38 * bp));
            rect.set(bx, by, bx + bw, by + bh); c.drawRoundRect(rect, bh, bh, bar);
            float sg = 22f * d, sx = bx + (bw - sg) * (0.5f - 0.5f * (float) Math.cos(t * 3.2f));
            bar.setColor(c0); bar.setAlpha((int) (255 * bp));
            rect.set(sx, by, sx + sg, by + bh); c.drawRoundRect(rect, bh, bh, bar);
        }
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        start = System.nanoTime();
        loop = ValueAnimator.ofFloat(0f, 1f);
        loop.setDuration(1000);
        loop.setRepeatCount(ValueAnimator.INFINITE);
        loop.setInterpolator(new LinearInterpolator());
        loop.addUpdateListener(an -> { t = (System.nanoTime() - start) / 1e9f; invalidate(); });
        loop.start();
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (loop != null) loop.cancel();
    }

    /** Closes like an iris onto the logo, revealing the page. */
    void exit(final Runnable end) {
        ValueAnimator e = ValueAnimator.ofFloat(0f, 1f);
        e.setDuration(750);
        e.setInterpolator(new DecelerateInterpolator(1.4f));
        e.addUpdateListener(an -> exitP = (float) an.getAnimatedValue());
        e.start();
        Animator rv = ViewAnimationUtils.createCircularReveal(this, (int) cx, (int) cy, (float) Math.hypot(W, H), 0f);
        rv.setDuration(750);
        rv.setInterpolator(new DecelerateInterpolator(1.4f));
        rv.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator an) { end.run(); }
        });
        rv.start();
    }
}
