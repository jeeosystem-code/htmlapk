package com.htmlapp.template;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.PixelCopy;
import android.view.WindowInsets;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.*;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    static final String HOST = "appassets.local";
    WebView web;
    FrameLayout root;
    ValueCallback<Uri[]> fileCb;
    PermissionRequest pendingReq;
    GeolocationPermissions.Callback geoCb;
    String geoOrigin;
    View customView;
    WebChromeClient.CustomViewCallback customCb;
    SplashView splash;
    boolean pageDone, dismissing;
    long splashStart;
    float insTop, insBottom, insLeft, insRight;
    boolean loaded, appAware, lightTop, lightNav;
    int baseFlags;
    final Handler ui = new Handler(Looper.getMainLooper());
    final Runnable sampler = new Runnable() {
        @Override public void run() { if (splash == null) sample(); ui.postDelayed(this, 1000); }
    };
    static final long SPLASH_MIN_MS = 2400;

    public class Bridge {
        @JavascriptInterface public void saveBase64(String name, String mime, String data) {
            save(name, mime, Base64.decode(data, Base64.DEFAULT));
        }
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        else baseFlags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        getWindow().setStatusBarContrastEnforced(false);
        getWindow().setNavigationBarContrastEnforced(false);
        root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        Drawable dr = getApplicationInfo().loadIcon(getPackageManager());
        Bitmap bmp = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888);
        dr.setBounds(0, 0, 192, 192);
        dr.draw(new Canvas(bmp));
        splash = new SplashView(this, bmp, getApplicationInfo().loadLabel(getPackageManager()).toString());
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));
        splashStart = SystemClock.uptimeMillis();
        applyBars();
        root.postDelayed(() -> { pageDone = true; maybeDismiss(); }, 8000);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setGeolocationEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (!HOST.equals(u.getHost()) || !"https".equals(u.getScheme())) return null;
                String path = u.getPath();
                if (path == null || path.equals("/")) path = "/index.html";
                try {
                    if (path.contains("..")) throw new IOException();
                    InputStream in = getAssets().open("www" + path);
                    String mime = mime(path);
                    boolean text = mime.startsWith("text/") || mime.contains("json") || mime.contains("javascript");
                    if (mime.equals("text/html") || mime.equals("text/css") || mime.equals("text/javascript")) {
                        String src = new String(readAll(in), StandardCharsets.UTF_8);
                        in.close();
                        src = src.replace("env(safe-area-inset-", "var(--safe-area-inset-");
                        if (mime.equals("text/html")) src = injectInsets(src);
                        in = new ByteArrayInputStream(src.getBytes(StandardCharsets.UTF_8));
                    }
                    return new WebResourceResponse(mime, text ? "utf-8" : null, in);
                } catch (IOException e) {
                    return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
                }
            }
            @Override public void onPageFinished(WebView v, String url) { pageDone = true; pushInsets(); maybeDismiss(); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String url = r.getUrl().toString();
                if (url.startsWith("http://") || url.startsWith("https://") || url.startsWith("file:") || url.startsWith("blob:") || url.startsWith("data:") || url.startsWith("about:")) return false;
                try {
                    Intent i = url.startsWith("intent:") ? Intent.parseUri(url, Intent.URI_INTENT_SCHEME) : new Intent(Intent.ACTION_VIEW, r.getUrl());
                    startActivity(i);
                } catch (Exception e) { Toast.makeText(MainActivity.this, "No app can open this link", Toast.LENGTH_SHORT).show(); }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    List<String> miss = new ArrayList<>();
                    for (String r : req.getResources()) {
                        String p = r.equals(PermissionRequest.RESOURCE_VIDEO_CAPTURE) ? Manifest.permission.CAMERA
                                : r.equals(PermissionRequest.RESOURCE_AUDIO_CAPTURE) ? Manifest.permission.RECORD_AUDIO : null;
                        if (p != null && checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) miss.add(p);
                    }
                    if (miss.isEmpty()) req.grant(req.getResources());
                    else { pendingReq = req; requestPermissions(miss.toArray(new String[0]), 11); }
                });
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    cb.invoke(origin, true, false);
                } else {
                    geoCb = cb; geoOrigin = origin;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 12);
                }
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try { startActivityForResult(params.createIntent(), 21); }
                catch (ActivityNotFoundException e) { fileCb = null; return false; }
                return true;
            }
            @Override public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) { cb.onCustomViewHidden(); return; }
                customView = v; customCb = cb;
                web.setVisibility(View.GONE);
                root.addView(v, new FrameLayout.LayoutParams(-1, -1));
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            }
            @Override public void onHideCustomView() { hideCustom(); }
            @Override public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
            @Override public boolean onJsPrompt(WebView v, String url, String msg, String def, final JsPromptResult r) {
                final EditText et = new EditText(MainActivity.this);
                et.setText(def);
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setView(et)
                        .setPositiveButton(android.R.string.ok, (d, w) -> r.confirm(et.getText().toString()))
                        .setNegativeButton(android.R.string.cancel, (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
        });
        web.setDownloadListener((url, ua, cd, mime, len) -> download(url, ua, cd, mime));
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            float den = getResources().getDisplayMetrics().density;
            int top, bot, lef, rig, imeB;
            boolean ime;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                top = bars.top; bot = bars.bottom; lef = bars.left; rig = bars.right;
                ime = ins.isVisible(WindowInsets.Type.ime());
                imeB = ins.getInsets(WindowInsets.Type.ime()).bottom;
            } else {
                top = ins.getSystemWindowInsetTop(); lef = ins.getSystemWindowInsetLeft(); rig = ins.getSystemWindowInsetRight();
                bot = ins.getStableInsetBottom();
                imeB = ins.getSystemWindowInsetBottom();
                ime = imeB - bot > 150;
            }
            root.setPadding(0, 0, 0, ime ? imeB : 0);
            insTop = top / den; insLeft = lef / den; insRight = rig / den;
            insBottom = ime ? 0f : bot / den;
            pushInsets();
            loadOnce();
            return ins;
        });
        root.requestApplyInsets();
        ui.postDelayed(this::loadOnce, 600);
    }

    void loadOnce() {
        if (loaded) return;
        loaded = true;
        try { appAware = scan("www"); } catch (Exception ignored) { }
        web.loadUrl("https://" + HOST + "/index.html");
    }

    boolean scan(String path) throws IOException {
        String[] kids = getAssets().list(path);
        if (kids != null && kids.length > 0) {
            for (String k : kids) if (scan(path + "/" + k)) return true;
            return false;
        }
        String l = path.toLowerCase(Locale.ROOT);
        if (!(l.endsWith(".html") || l.endsWith(".htm") || l.endsWith(".css") || l.endsWith(".js") || l.endsWith(".mjs"))) return false;
        try (InputStream in = getAssets().open(path)) {
            return new String(readAll(in), StandardCharsets.ISO_8859_1).contains("safe-area-inset");
        }
    }

    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        return o.toByteArray();
    }

    void pushInsets() {
        if (web == null) return;
        web.evaluateJavascript("(function(){var s=document.documentElement.style;"
                + "s.setProperty('--safe-area-inset-top','" + insTop + "px');s.setProperty('--safe-area-inset-right','" + insRight + "px');"
                + "s.setProperty('--safe-area-inset-bottom','" + insBottom + "px');s.setProperty('--safe-area-inset-left','" + insLeft + "px');})();", null);
    }

    String injectInsets(String html) {
        String style = "<style id=\"__safe\">:root{--safe-area-inset-top:" + insTop + "px;--safe-area-inset-right:" + insRight
                + "px;--safe-area-inset-bottom:" + insBottom + "px;--safe-area-inset-left:" + insLeft + "px}"
                + (appAware ? "" : "html{box-sizing:border-box;padding:var(--safe-area-inset-top) var(--safe-area-inset-right) var(--safe-area-inset-bottom) var(--safe-area-inset-left)}")
                + "</style>";
        String low = html.toLowerCase(Locale.ROOT);
        int at = tagEnd(low, "<head");
        if (at < 0) at = tagEnd(low, "<html");
        if (at < 0) at = Math.max(0, low.indexOf("<body"));
        return html.substring(0, at) + style + html.substring(at);
    }

    static int tagEnd(String low, String tag) {
        int st = low.indexOf(tag);
        if (st < 0) return -1;
        int e = low.indexOf('>', st);
        return e < 0 ? -1 : e + 1;
    }

    void applyBars() {
        int f = baseFlags;
        if (lightTop) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (lightNav) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(f);
    }

    static float lum(Bitmap b) {
        float r = 0, g = 0, bl = 0;
        int n = b.getWidth() * b.getHeight();
        for (int y = 0; y < b.getHeight(); y++)
            for (int x = 0; x < b.getWidth(); x++) {
                int p = b.getPixel(x, y);
                r += Color.red(p); g += Color.green(p); bl += Color.blue(p);
            }
        return (0.299f * r + 0.587f * g + 0.114f * bl) / n / 255f;
    }

    /** Looks at what is drawn under the status and navigation bars and picks dark or light icons. */
    void sample() {
        int w = root.getWidth(), h = root.getHeight();
        if (w <= 0 || h <= 0 || customView != null) return;
        float den = getResources().getDisplayMetrics().density;
        int tp = Math.min(h, Math.max(1, Math.round(insTop * den)));
        int bp = Math.min(h, Math.max(1, Math.round(insBottom * den)));
        try {
            final Bitmap top = Bitmap.createBitmap(16, 4, Bitmap.Config.ARGB_8888);
            PixelCopy.request(getWindow(), new Rect(0, 0, w, tp), top, res -> {
                if (res == PixelCopy.SUCCESS) { boolean l = lum(top) > 0.55f; if (l != lightTop) { lightTop = l; applyBars(); } }
            }, ui);
            final Bitmap bot = Bitmap.createBitmap(16, 4, Bitmap.Config.ARGB_8888);
            PixelCopy.request(getWindow(), new Rect(0, h - bp, w, h), bot, res -> {
                if (res == PixelCopy.SUCCESS) { boolean l = lum(bot) > 0.55f; if (l != lightNav) { lightNav = l; applyBars(); } }
            }, ui);
        } catch (Exception ignored) { }
    }

    void maybeDismiss() {
        if (splash == null || dismissing || !pageDone) return;
        long wait = SPLASH_MIN_MS - (SystemClock.uptimeMillis() - splashStart);
        if (wait > 0) { root.postDelayed(this::maybeDismiss, wait); return; }
        dismissing = true;
        final SplashView sv = splash;
        root.setBackgroundColor(Color.WHITE);
        sv.exit(() -> { root.removeView(sv); splash = null; });
    }

    void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        web.setVisibility(View.VISIBLE);
        applyBars();
        WebChromeClient.CustomViewCallback cb = customCb;
        customCb = null;
        if (cb != null) cb.onCustomViewHidden();
    }

    static String mime(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        if (p.endsWith(".js") || p.endsWith(".mjs")) return "text/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".html") || p.endsWith(".htm")) return "text/html";
        if (p.endsWith(".json") || p.endsWith(".webmanifest")) return "application/json";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".wasm")) return "application/wasm";
        String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(MimeTypeMap.getFileExtensionFromUrl(p));
        return m != null ? m : "application/octet-stream";
    }

    void download(String url, String ua, String cd, String mime) {
        try {
            String name = URLUtil.guessFileName(url, cd, mime);
            if (url.startsWith("blob:")) {
                String js = "(function(){var x=new XMLHttpRequest();x.open('GET'," + JSONObject.quote(url) + ",true);x.responseType='blob';"
                        + "x.onload=function(){var r=new FileReader();r.onloadend=function(){AndroidBridge.saveBase64(" + JSONObject.quote(name) + ","
                        + JSONObject.quote(mime == null ? "application/octet-stream" : mime) + ",r.result.split(',')[1]);};r.readAsDataURL(x.response);};x.send();})();";
                web.evaluateJavascript(js, null);
            } else if (url.startsWith("data:")) {
                int c = url.indexOf(',');
                String meta = url.substring(5, c), data = url.substring(c + 1);
                byte[] bytes = meta.contains(";base64") ? Base64.decode(data, Base64.DEFAULT) : Uri.decode(data).getBytes(StandardCharsets.UTF_8);
                save(name, mime, bytes);
            } else if (url.startsWith("https://" + HOST + "/")) {
                String path = Uri.parse(url).getPath();
                try (InputStream in = getAssets().open("www" + path); ByteArrayOutputStream o = new ByteArrayOutputStream()) {
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
                    save(name, mime, o.toByteArray());
                }
            } else {
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                r.setMimeType(mime);
                String ck = CookieManager.getInstance().getCookie(url);
                if (ck != null) r.addRequestHeader("cookie", ck);
                r.addRequestHeader("User-Agent", ua);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
                toast("Downloading " + name);
            }
        } catch (Exception e) { toast("Download failed"); }
    }

    void save(String name, String mime, byte[] bytes) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime == null ? "application/octet-stream" : mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(bytes); }
            toast("Saved to Downloads: " + name);
        } catch (Exception e) { toast("Could not save file"); }
    }

    void toast(final String m) { runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_SHORT).show()); }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (req == 21 && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        }
    }

    @Override public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        boolean all = r.length > 0, any = false;
        for (int x : r) { if (x == PackageManager.PERMISSION_GRANTED) any = true; else all = false; }
        if (code == 11 && pendingReq != null) {
            if (all) pendingReq.grant(pendingReq.getResources()); else pendingReq.deny();
            pendingReq = null;
        }
        if (code == 12 && geoCb != null) { geoCb.invoke(geoOrigin, any, false); geoCb = null; }
    }

    @Override public void onBackPressed() {
        if (customView != null) hideCustom();
        else if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
    @Override protected void onPause() { super.onPause(); ui.removeCallbacks(sampler); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); ui.removeCallbacks(sampler); ui.postDelayed(sampler, 500); }
    @Override protected void onDestroy() { super.onDestroy(); web.destroy(); }
}
